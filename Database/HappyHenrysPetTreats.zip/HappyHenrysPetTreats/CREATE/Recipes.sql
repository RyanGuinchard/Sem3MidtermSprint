CREATE TABLE Recipes (
    RecipeID SERIAL PRIMARY KEY,
    ProductID INTEGER REFERENCES Products(ProductID),
    Description TEXT,
    Cost DECIMAL(10, 2)
);
