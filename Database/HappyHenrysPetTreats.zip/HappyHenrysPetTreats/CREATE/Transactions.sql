CREATE TABLE Transactions (
    TransactionID SERIAL PRIMARY KEY,
    OrderID INTEGER REFERENCES Orders(OrderID),
    Amount DECIMAL(10, 2),
    TransactionDate DATE
);
