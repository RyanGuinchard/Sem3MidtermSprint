CREATE TABLE Order (
    OrderID SERIAL PRIMARY KEY,
    CustomerID INTEGER REFERENCES Customer(CustomerID),
    OrderDate DATE,
    Status VARCHAR(50)
);
