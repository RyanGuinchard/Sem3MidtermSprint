CREATE TABLE Inventory (
    InventoryID SERIAL PRIMARY KEY,
    ProductID INTEGER REFERENCES Products(ProductID),
    QuantityAvailable INTEGER
);
