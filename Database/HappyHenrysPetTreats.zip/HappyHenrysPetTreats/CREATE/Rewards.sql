CREATE TABLE Rewards (
    RewardID SERIAL PRIMARY KEY,
    CustomerID INTEGER REFERENCES Customers(CustomerID),
    PointsEarned INTEGER DEFAULT 0,
    PointsRedeemed INTEGER DEFAULT 0,
    CurrentBalance AS (PointsEarned - PointsRedeemed) STORED
);
