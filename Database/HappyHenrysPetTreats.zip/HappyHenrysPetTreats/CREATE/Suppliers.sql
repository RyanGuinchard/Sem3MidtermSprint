CREATE TABLE Suppliers (
    SupplierID SERIAL PRIMARY KEY,
    Name VARCHAR(255),
    ContactInfo VARCHAR(255)
);
