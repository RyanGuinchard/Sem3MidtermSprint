-- will retrieve all customers and their order details
SELECT c.FirstName, c.LastName, o.OrderID, o.OrderDate, o.Status
FROM Customers c
JOIN Orders o ON c.CustomerID = o.CustomerID
ORDER BY c.LastName, c.FirstName, o.OrderDate;
