-- customers who have placed orders in the last 3 months
SELECT c.FirstName, c.LastName, MAX(o.OrderDate) AS LastOrderDate
FROM Customers c
JOIN Orders o ON c.CustomerID = o.CustomerID
WHERE o.OrderDate >= CURRENT_DATE - INTERVAL '3 months'
GROUP BY c.CustomerID
ORDER BY LastOrderDate DESC;
