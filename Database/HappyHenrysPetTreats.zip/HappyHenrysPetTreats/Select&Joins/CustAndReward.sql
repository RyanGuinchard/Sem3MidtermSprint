-- shows each customer's total reward points
SELECT c.FirstName, c.LastName, SUM(r.PointsEarned) - SUM(r.PointsRedeemed) AS TotalPoints
FROM Customers c
JOIN Rewards r ON c.CustomerID = r.CustomerID
GROUP BY c.CustomerID
HAVING SUM(r.PointsEarned) - SUM(r.PointsRedeemed) > 0
ORDER BY TotalPoints DESC;
