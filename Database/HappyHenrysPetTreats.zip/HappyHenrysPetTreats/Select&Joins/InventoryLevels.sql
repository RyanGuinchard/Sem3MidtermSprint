-- llists all products with their current inventory levels
-- can be used to tell what is running low and needs to be ordered
SELECT p.Name, i.QuantityAvailable
FROM Products p
JOIN Inventory i ON p.ProductID = i.ProductID
WHERE i.QuantityAvailable < 10
ORDER BY i.QuantityAvailable ASC;
