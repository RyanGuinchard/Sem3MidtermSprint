-- finds all orders that are 'shipped' but not yet 'delivered'
SELECT o.OrderID, o.OrderDate, c.FirstName, c.LastName
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
WHERE o.Status = 'shipped'
ORDER BY o.OrderDate;
